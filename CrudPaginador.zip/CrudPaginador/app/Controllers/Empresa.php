<?php
namespace App\Controllers;

use App\Models\EmpresaModel;
use CodeIgniter\API\ResponseTrait;

class Empresa extends BaseController
{
    use ResponseTrait;

    public function index()
    {
        $model = new EmpresaModel();
        
         $data = [
             'nombre' => 'coca-cola',
             'nit'  => '00-553-2111',

         ];
         $customer = $model->save($data);
        
        //echo json_encode($data);
        return $this->setResponseFormat('json')->respond($data); 
    }
    

}











