<?php
namespace App\Models;

use CodeIgniter\Model;

class EmpresaModel extends Model
{
    
    protected $table = "empresas";

    protected $primarykey  = "id";

    protected $useAutoIncrement = true;

    protected $returnType = "array";

    protected $allowedFields = ['nombre','nit'];

    protected $useTimestamps = false;

    protected $validationRules = [
        'nit' => 'required|is_unique[]'
    ];

    protected $validationMessages = [
        'nit' => [
            'required' => 'Ingresar un formato correcto',
            'is_unique' => 'Nit duplicado'
        ]
    ];

    protected $skipValidation = false;


}