<?= $this->extend('templates/administrador') ?>

<?= $this->section('content') ?>

<!-- Content Header (Page header) -->
<
    <!-- /.content -->
<?= $this->endSection() ?>