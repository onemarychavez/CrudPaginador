<?= $this->extend('templates/administrador') ?>

<?= $this->section('content') ?>


<?= $this->endSection() ?>
